package com.insurance.insuranceCompany.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.insurance.insuranceCompany.contract.*;
import com.insurance.insuranceCompany.model.DiseaseDetails;
import com.insurance.insuranceCompany.model.InsurancePackage;
import com.insurance.insuranceCompany.model.InsurancePackageCoveredDisease;
import com.insurance.insuranceCompany.Dao.*;

@Service
public class InsurancePackageServiceImpl implements InsurancePackageService {

	 private final InsurancePackageDAO insurancePackageDAO;
	    
	    @Autowired
	    public InsurancePackageServiceImpl(InsurancePackageDAO insurancePackageDAO) {
	        this.insurancePackageDAO = insurancePackageDAO;
	    }

	    @Override
	    public List<InsurancePackage> getAllInsurancePackages() {
	        return insurancePackageDAO.getAllInsurancePackages();
	    }
	    
	    public List<InsurancePackageCoveredDisease> getCoveredDiseasesByPackageId(int packageId) {
	        return insurancePackageDAO.getCoveredDiseasesByPackageId(packageId);
	    }

		@Override
		public DiseaseDetails getDiseaseDetailsById(int discId) {
			// TODO Auto-generated method stub
			return  insurancePackageDAO.getDetailsByDiseaseId(discId);
		}

		@Override
		public List<InsurancePackage> getFilteredPackages(String status, int age) {
			return  insurancePackageDAO.getFiteredDiseases(status,age);
		}

		@Override
		public List<InsurancePackage> getPackagesByStatus(String status) {
			// TODO Auto-generated method stub
			return  insurancePackageDAO.getPackagesByStatus(status);
		}

		@Override
		public List<InsurancePackage> getAllInsurancePackagesByAge(int age) {
			// TODO Auto-generated method stub
			return  insurancePackageDAO.getAllInsurancePackagesByAge(age);
		}
		
		
		@Override
		public List<DiseaseDetails> getDiseasesByPackageId(int id) {
			return  insurancePackageDAO.getDiseasesByPackageId(id);
			
		}

		@Override
		public int addDisease(String name, String iCDCode, String description, String status,int inspid) {
			// TODO Auto-generated method stub
			return insurancePackageDAO.addDisease(name,iCDCode,description,status,inspid);
		}

		@Override
		public int deleteDisease(int did, int inspid) {
			return insurancePackageDAO.deleteDisease(did,inspid);
			
		}

		@Override
		public String editDisease(String name, String iCDCode, String description, String status) {
			// TODO Auto-generated method stub
			return insurancePackageDAO.editDisease(name, iCDCode, description,status);
		}
		

	}




